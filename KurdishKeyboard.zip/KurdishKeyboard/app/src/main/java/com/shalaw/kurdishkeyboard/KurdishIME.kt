package com.shalaw.kurdishkeyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.View
import android.view.inputmethod.EditorInfo

/**
 * The Kurdish (Shalaw) keyboard input method.
 *
 * Special key codes used in kurdish_keyboard.xml / symbols_keyboard.xml:
 *   -2   -> switch between letters keyboard and symbols/numbers keyboard
 *   -4   -> perform the editor's action (search / go / enter)
 *   -5   -> backspace (delete one character before the cursor)
 *   -6   -> insert an emoji
 *   -101 -> insert "وو" (the two-letter combination) in a single key press
 */
class KurdishIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var lettersKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard
    private var showingSymbols = false

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as KeyboardView
        lettersKeyboard = Keyboard(this, R.xml.kurdish_keyboard)
        symbolsKeyboard = Keyboard(this, R.xml.symbols_keyboard)
        keyboardView.keyboard = lettersKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        return keyboardView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        showingSymbols = false
        keyboardView.keyboard = lettersKeyboard
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return

        when (primaryCode) {
            -2 -> { // 12!# <-> کوردی
                showingSymbols = !showingSymbols
                keyboardView.keyboard = if (showingSymbols) symbolsKeyboard else lettersKeyboard
            }
            -5 -> { // backspace
                ic.deleteSurroundingText(1, 0)
            }
            -4 -> { // search / go / enter action of the current field
                sendDefaultEditorAction(true)
            }
            -6 -> { // emoji
                ic.commitText("😀", 1)
            }
            -101 -> { // وو
                ic.commitText("وو", 1)
            }
            32 -> { // space
                ic.commitText(" ", 1)
            }
            else -> {
                val text = String(Character.toChars(primaryCode))
                ic.commitText(text, 1)
            }
        }
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeUp() {}
    override fun swipeDown() {}
}
